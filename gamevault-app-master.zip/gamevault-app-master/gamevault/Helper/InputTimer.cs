﻿using System.Windows.Threading;

namespace gamevault.Helper
{
    public class InputTimer : DispatcherTimer
    {
        public string Data;
    }
}
